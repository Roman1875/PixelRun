extends SceneTree
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game = load("res://main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.start_game()
	var failures := 0
	for i in range(3):
		if i > 0:
			game._load_level(i)
		for n in range(30):
			await physics_frame
		var before: int = game.deaths
		Input.action_press("move_right")
		var hold := 0
		for n in range(1000):
			await physics_frame
			var p = game.level.player
			if game.level.finished:
				break
			if game.deaths > before:
				break
			hold = maxi(0, hold - 1)
			if hold == 0 and Input.is_action_pressed("jump"):
				Input.action_release("jump")
			if p.is_on_floor():
				var jump := false
				for platform in game.level.LEVELS[i]["platforms"]:
					if absf(p.position.y + 15.0 - platform[1]) < 3.0 and p.position.x >= platform[0] - 5 and p.position.x < platform[0]+platform[2]+10:
						if platform[0]+platform[2]-p.position.x <= (60.0 if i == 0 else (40.0 if i == 2 and platform[1] == 330 else 15.0)):
							jump = true
				for spike in game.level.LEVELS[i]["spikes"]:
					if absf(p.position.y + 15.0 - spike[1]) < 3.0 and spike[0]-p.position.x >= -5 and spike[0]-p.position.x <= 65:
						jump = true
				if jump and not Input.is_action_pressed("jump"):
					Input.action_press("jump")
					hold = 30
		Input.action_release("move_right")
		Input.action_release("jump")
		if game.level.finished:
			print("PASS ROUTE: level ", i+1, " completed without teleport or death")
		else:
			print("FAIL ROUTE: level ", i+1," at ",game.level.player.position)
			failures += 1
	game._return_menu()
	await process_frame
	quit(failures)
