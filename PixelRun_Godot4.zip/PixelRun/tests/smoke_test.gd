extends SceneTree
var game: Node
var failures: int = 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print("PASS: " if condition else "FAIL: ", description)
	if not condition:
		failures += 1

func frames(n: int) -> void:
	for i in range(n):
		await physics_frame

func shot(_name: String) -> void:
	await process_frame

func run() -> void:
	game = load("res://main.tscn").instantiate()
	root.add_child(game)
	await frames(5)
	await shot("pixel-menu")
	game.start_game()
	await frames(30)
	check(game.level.player.is_on_floor(), "player starts on platform")
	await shot("pixel-level1")
	var x: float = game.level.player.position.x
	Input.action_press("move_right")
	await frames(30)
	Input.action_release("move_right")
	check(game.level.player.position.x > x + 80, "horizontal movement")
	var y: float = game.level.player.position.y
	Input.action_press("jump")
	await frames(12)
	Input.action_release("jump")
	check(game.level.player.position.y < y - 40, "jump moves player upward")
	await frames(60)
	game._on_pause()
	var old_position: Vector2 = game.level.player.position
	Input.action_press("move_right")
	await frames(8)
	check(game.level.player.position == old_position, "pause freezes world")
	Input.action_release("move_right")
	await shot("pixel-pause")
	game._resume()
	var checkpoint := Vector2(1085,460)
	game.level.player.position = checkpoint + Vector2(10,-25)
	game.level.player.velocity = Vector2.ZERO
	await frames(5)
	check(game.level.spawn_point == checkpoint + Vector2(12,-25), "checkpoint activated")
	game.level.player.position = Vector2(665,440)
	game.level.player.velocity = Vector2.ZERO
	await frames(4)
	check(game.deaths == 1, "spikes cause death")
	await create_timer(0.5).timeout
	check(not game.level.player.frozen and absf(game.level.player.position.x - 1097.0) < 2.0, "respawn at checkpoint")
	game._load_level(0)
	await frames(10)
	check(game.level.coins == 0, "restart resets level coins")
	for index in range(3):
		if index > 0:
			game._load_level(index)
		await frames(5)
		for point in game.level.LEVELS[index]["coins"]:
			game.level.player.position = point
			game.level.player.velocity = Vector2.ZERO
			await frames(3)
		check(game.level.coins == game.level.get_coin_count(), "level %d: all coins collectable" % (index+1))
		# Inspect the later half of each level as well.
		game.level.player.position = Vector2(1570,280) if index == 2 else Vector2(1280,420)
		game.level.player.velocity = Vector2.ZERO
		game.level.camera.position = Vector2(game.level.player.position.x,270)
		game.level.camera.reset_smoothing()
		await frames(5)
		await shot("pixel-level%d-late" % (index+1))
		game.level.player.position = game.level.LEVELS[index]["goal"] + Vector2(10,-30)
		game.level.player.velocity = Vector2.ZERO
		await frames(5)
		check(game.level.finished and paused, "level %d: goal completes level" % (index+1))
	check(game.banked_coins == 37 and game.overlay_kind == "win", "victory with 37 coins")
	await shot("pixel-win")
	game._return_menu()
	await frames(2)
	check(not game.playing and not paused, "return to menu unpauses tree")
	print("TEST FAILURES: ", failures)
	quit(1 if failures > 0 else 0)
