extends CharacterBody2D
## Player movement: coyote time, jump buffer, variable jump height.
signal died
const SPEED: float = 260.0
const JUMP_SPEED: float = -520.0
const GRAVITY: float = 1250.0
var frozen: bool = false
var facing: float = 1.0
var coyote: float = 0.0
var jump_buffer: float = 0.0
var animation_time: float = 0.0

func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	var shape := RectangleShape2D.new()
	shape.size = Vector2(22, 30)
	var collider := CollisionShape2D.new()
	collider.shape = shape
	add_child(collider)

func _physics_process(delta: float) -> void:
	if frozen:
		return
	animation_time += delta
	coyote = 0.10 if is_on_floor() else maxf(0.0, coyote - delta)
	jump_buffer = maxf(0.0, jump_buffer - delta)
	if Input.is_action_just_pressed("jump"):
		jump_buffer = 0.12
	if not is_on_floor():
		velocity.y = minf(velocity.y + GRAVITY * delta, 850.0)
	if jump_buffer > 0.0 and coyote > 0.0:
		velocity.y = JUMP_SPEED
		jump_buffer = 0.0
		coyote = 0.0
	if Input.is_action_just_released("jump") and velocity.y < -180.0:
		velocity.y = -180.0
	var direction := Input.get_axis("move_left", "move_right")
	velocity.x = move_toward(velocity.x, direction * SPEED, 1800.0 * delta)
	if direction != 0.0:
		facing = direction
	move_and_slide()
	if position.y > 670.0:
		die()
	queue_redraw()

func die() -> void:
	if frozen:
		return
	frozen = true
	died.emit()

func respawn(at: Vector2) -> void:
	position = at
	velocity = Vector2.ZERO
	coyote = 0.0
	jump_buffer = 0.0
	frozen = false

func _draw() -> void:
	# Deliberately pixel-shaped character; no external art required.
	var step: float = 2.0 if is_on_floor() and absf(velocity.x) > 30.0 and sin(animation_time * 18.0) > 0.0 else 0.0
	draw_rect(Rect2(-10, -14, 20, 24), Color("48d9e8"))
	draw_rect(Rect2(-10, -14, 20, 5), Color("b4fbef"))
	draw_rect(Rect2(-7, -5, 14, 6), Color("12233e"))
	draw_rect(Rect2(1 if facing > 0 else -5, -4, 4, 3), Color("ffffff"))
	draw_rect(Rect2(-10, 8, 8, 7 - step), Color("218fac"))
	draw_rect(Rect2(2, 8, 8, 5 + step), Color("218fac"))
	draw_rect(Rect2(-14 if facing > 0 else 8, 0, 6, 4), Color("ffc778"))
