extends Area2D
## Types: coin, spike, goal, checkpoint.
signal touched(item: Area2D)
var kind: String = "coin"
var width: float = 24.0
var active: bool = false
var clock: float = 0.0

func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var collider := CollisionShape2D.new()
	if kind == "coin":
		var circle := CircleShape2D.new()
		circle.radius = 12.0
		collider.shape = circle
	else:
		var rectangle := RectangleShape2D.new()
		rectangle.size = Vector2(width - 6.0, 16) if kind == "spike" else Vector2(26, 62)
		collider.shape = rectangle
		collider.position = Vector2(width / 2.0, -8) if kind == "spike" else Vector2(10, -31)
	add_child(collider)
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		touched.emit(self)

func _process(delta: float) -> void:
	clock += delta
	queue_redraw()

func _draw() -> void:
	match kind:
		"coin":
			var bob := Vector2(0, sin(clock * 3.5) * 3)
			draw_rect(Rect2(bob + Vector2(-7, -10), Vector2(14, 20)), Color("ffc778"))
			draw_rect(Rect2(bob + Vector2(-10, -6), Vector2(20, 12)), Color("ffc778"))
			draw_rect(Rect2(bob + Vector2(-2, -6), Vector2(4, 12)), Color("fff1bf"))
		"spike":
			for x in range(0, int(width), 24):
				draw_colored_polygon(PackedVector2Array([Vector2(x, 0), Vector2(x + 12, -22), Vector2(x + 24, 0)]), Color("fb7794"))
		"goal", "checkpoint":
			var color := Color("62e3bf") if kind == "goal" or active else Color("92a0bd")
			draw_rect(Rect2(0, -64, 4, 64), Color("e6edff"))
			draw_rect(Rect2(4, -62, 30, 20), color)
			draw_rect(Rect2(4, -42, 18, 6), color.darkened(0.3))
			draw_rect(Rect2(-6, -4, 18, 4), Color("e6edff"))
