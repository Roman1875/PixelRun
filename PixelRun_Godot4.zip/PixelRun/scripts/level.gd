extends Node2D
signal coin_collected(total: int)
signal completed
signal checkpoint_reached
signal player_died
const PlayerScript = preload("res://scripts/player.gd")
const PlatformScript = preload("res://scripts/platform.gd")
const PickupScript = preload("res://scripts/pickup.gd")

# Platform tuples: x, y, width, height. Spike tuples: x, ground y, width.
# Maximum jump height ~108 px; keep platforms within that range.
const LEVELS: Array[Dictionary] = [
	{
		"name": "Зелений старт", "width": 2180, "accent": "62e3bf",
		"spawn": Vector2(70, 420),
		"platforms": [[0,460,460,100],[540,460,420,100],[1060,460,390,100],[1540,460,640,100],[260,380,120,20],[740,380,120,20],[1240,380,100,20],[1740,380,130,20]],
		"spikes": [[650,460,48],[1140,460,48],[1650,460,48]],
		"coins": [Vector2(180,420),Vector2(300,345),Vector2(415,415),Vector2(500,380),Vector2(790,345),Vector2(1005,380),Vector2(1290,345),Vector2(1495,380),Vector2(1800,345),Vector2(1980,420)],
		"checkpoint": Vector2(1085,460), "goal": Vector2(2090,460)
	},
	{
		"name": "Сходи над прірвою", "width": 2340, "accent": "78b4ff",
		"spawn": Vector2(70,420),
		"platforms": [[0,460,330,100],[420,420,160,24],[665,360,170,24],[920,420,200,140],[1200,460,380,100],[1660,410,170,24],[1910,360,170,24],[2140,420,200,140]],
		"spikes": [[1010,420,48],[1400,460,72]],
		"coins": [Vector2(185,420),Vector2(375,365),Vector2(495,375),Vector2(620,315),Vector2(740,315),Vector2(875,315),Vector2(970,380),Vector2(1320,415),Vector2(1620,355),Vector2(1740,365),Vector2(1870,305),Vector2(1990,315),Vector2(2240,380)],
		"checkpoint": Vector2(1230,460), "goal": Vector2(2275,420)
	},
	{
		"name": "Останній ривок", "width": 2500, "accent": "c19aff",
		"spawn": Vector2(70,420),
		"platforms": [[0,460,360,100],[460,460,270,100],[830,410,190,24],[1110,350,200,24],[1390,410,330,150],[1810,460,260,100],[2160,420,340,140],[245,380,80,20],[570,380,90,20],[1480,330,120,20],[1910,380,90,20],[2290,340,100,20]],
		"spikes": [[505,460,48],[1430,410,24],[1615,410,48],[1860,460,48],[2190,420,24]],
		"coins": [Vector2(170,420),Vector2(285,345),Vector2(410,380),Vector2(615,345),Vector2(780,345),Vector2(925,365),Vector2(1065,305),Vector2(1210,305),Vector2(1350,305),Vector2(1540,295),Vector2(1765,345),Vector2(1960,345),Vector2(2115,355),Vector2(2340,305)],
		"checkpoint": Vector2(1398,410), "goal": Vector2(2420,420)
	}
]
var player: CharacterBody2D
var camera: Camera2D
var spawn_point: Vector2
var coins: int = 0
var finished: bool = false
var level_index: int = 0

func build(index: int) -> void:
	level_index = index
	var data: Dictionary = LEVELS[index]
	spawn_point = data["spawn"]
	for tuple in data["platforms"]:
		var tile = PlatformScript.new()
		tile.position = Vector2(tuple[0], tuple[1])
		tile.size = Vector2(tuple[2], tuple[3])
		tile.accent = Color(data["accent"])
		add_child(tile)
	for tuple in data["spikes"]:
		add_item("spike", Vector2(tuple[0], tuple[1]), float(tuple[2]))
	for point in data["coins"]:
		add_item("coin", point)
	add_item("checkpoint", data["checkpoint"])
	add_item("goal", data["goal"])
	player = PlayerScript.new()
	player.position = spawn_point
	player.died.connect(_on_death)
	add_child(player)
	camera = Camera2D.new()
	camera.position = Vector2(480, 270)
	camera.limit_left = 0
	camera.limit_right = data["width"]
	camera.limit_top = 0
	camera.limit_bottom = 540
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
	add_child(camera)
	camera.make_current()

func _process(_delta: float) -> void:
	if is_instance_valid(player):
		camera.position = Vector2(clampf(player.position.x, 480, LEVELS[level_index]["width"] - 480), 270)

func add_item(type: String, point: Vector2, item_width: float = 24.0) -> Area2D:
	var item = PickupScript.new()
	item.kind = type
	item.width = item_width
	item.position = point
	item.touched.connect(_on_item)
	add_child(item)
	return item

func _on_item(item: Area2D) -> void:
	if finished or player.frozen:
		return
	match item.kind:
		"coin":
			if item.active:
				return
			item.active = true
			item.set_deferred("monitoring", false)
			item.hide()
			coins += 1
			coin_collected.emit(coins)
		"spike":
			player.die()
		"checkpoint":
			if not item.active:
				item.active = true
				spawn_point = item.position + Vector2(12, -25)
				checkpoint_reached.emit()
		"goal":
			finished = true
			player.frozen = true
			completed.emit()

func _on_death() -> void:
	player_died.emit()
	await get_tree().create_timer(0.35, false).timeout
	if is_instance_valid(player) and not finished:
		player.respawn(spawn_point)
		camera.position = Vector2(clampf(spawn_point.x, 480, LEVELS[level_index]["width"] - 480), 270)
		camera.reset_smoothing()

func get_coin_count() -> int:
	return LEVELS[level_index]["coins"].size()
