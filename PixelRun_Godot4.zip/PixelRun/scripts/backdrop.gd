extends Node2D
var accent: Color = Color("62e3bf")
func _draw() -> void:
	draw_rect(Rect2(0,0,960,540), Color("0c1429"))
	for i in range(50):
		var x := float((i * 173 + 21) % 950)
		var y := float((i * 67 + 17) % 300)
		draw_rect(Rect2(x,y,2,2), Color("526181"))
	draw_rect(Rect2(735,100,58,58), accent.darkened(0.15))
	draw_rect(Rect2(725,115,78,30), accent.darkened(0.15))
	for i in range(11):
		var h: float = float(80 + (i * 43) % 120)
		draw_rect(Rect2(i * 100, 450 - h, 80, h + 90), Color("14233c"))
		for y in range(int(450-h+15),430,24):
			draw_rect(Rect2(i*100+12,y,5,5), Color("243653"))
			draw_rect(Rect2(i*100+52,y,5,5), Color("243653"))
	draw_rect(Rect2(0,490,960,50), Color("101b31"))
