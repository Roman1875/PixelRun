extends StaticBody2D
var size: Vector2 = Vector2(200, 60)
var accent: Color = Color("62e3bf")

func _ready() -> void:
	collision_layer = 1
	collision_mask = 0
	var shape := RectangleShape2D.new()
	shape.size = size
	var collider := CollisionShape2D.new()
	collider.shape = shape
	collider.position = size / 2.0
	add_child(collider)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("1c2c46"))
	draw_rect(Rect2(0, 0, size.x, 6), accent)
	draw_rect(Rect2(0, 6, size.x, 6), accent.darkened(0.45))
	for x in range(8, int(size.x) - 8, 32):
		for y in range(24, int(size.y) - 8, 32):
			draw_rect(Rect2(x, y, 12, 5), Color("293d59"))
