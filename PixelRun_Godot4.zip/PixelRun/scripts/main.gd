extends Node2D
const LevelScript = preload("res://scripts/level.gd")
const BackdropScript = preload("res://scripts/backdrop.gd")
var level: Node2D
var backdrop: Node2D
var ui: CanvasLayer
var hud: Control
var level_label: Label
var coin_label: Label
var death_label: Label
var message_label: Label
var overlay: Control
var level_index: int = 0
var banked_coins: int = 0
var deaths: int = 0
var playing: bool = false
var paused: bool = false
var overlay_kind: String = "menu"

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_input()
	var theme := Theme.new()
	theme.default_font = preload("res://assets/Interface.ttf")
	theme.default_font_size = 20
	var style := StyleBoxFlat.new()
	style.bg_color = Color("253d58")
	style.border_color = Color("486484")
	style.set_border_width_all(2)
	style.set_content_margin_all(14)
	theme.set_stylebox("normal", "Button", style)
	var hover := style.duplicate() as StyleBoxFlat
	hover.bg_color = Color("365778")
	theme.set_stylebox("hover", "Button", hover)
	var focus := style.duplicate() as StyleBoxFlat
	focus.border_color = Color("62e3bf")
	theme.set_stylebox("focus", "Button", focus)
	var background_layer := CanvasLayer.new()
	background_layer.layer = -10
	add_child(background_layer)
	backdrop = BackdropScript.new()
	background_layer.add_child(backdrop)
	ui = CanvasLayer.new()
	ui.layer = 10
	add_child(ui)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = theme
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	_make_hud(root)
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(overlay)
	_show_menu()

func _setup_input() -> void:
	var bindings := {"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT], "jump": [KEY_SPACE, KEY_W, KEY_UP]}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key in bindings[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)

func _label(text: String, size: int, color: Color = Color("e9f0ff")) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return label

func _make_hud(root: Control) -> void:
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	var strip := ColorRect.new()
	strip.color = Color(0.04,0.07,0.14,0.94)
	strip.position = Vector2(0,0)
	strip.size = Vector2(960,66)
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(strip)
	level_label = _label("", 20)
	level_label.position = Vector2(24,20)
	level_label.size = Vector2(420,28)
	level_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hud.add_child(level_label)
	coin_label = _label("", 20, Color("ffc778"))
	coin_label.position = Vector2(475,20)
	coin_label.size = Vector2(200,28)
	hud.add_child(coin_label)
	death_label = _label("", 20)
	death_label.position = Vector2(708,20)
	death_label.size = Vector2(228,28)
	hud.add_child(death_label)
	var help := _label("A / D або ← / → — рух     •     Пробіл — стрибок     •     R — рівень заново     •     Esc — пауза", 17, Color("aebdd8"))
	help.position = Vector2(15,505)
	help.size = Vector2(930,28)
	hud.add_child(help)
	message_label = _label("", 19, Color("62e3bf"))
	message_label.position = Vector2(240,82)
	message_label.size = Vector2(480,30)
	hud.add_child(message_label)

func _panel(title: String, subtitle: String) -> VBoxContainer:
	for child in overlay.get_children():
		overlay.remove_child(child)
		child.queue_free()
	overlay.show()
	var dim := ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.025,0.045,0.10,0.90)
	overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(640,0)
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)
	box.add_child(_label("P I X E L   R U N", 17, Color("62e3bf")))
	box.add_child(_label(title, 48))
	box.add_child(_label(subtitle, 20, Color("b3c2de")))
	return box

func _button(box: VBoxContainer, text: String, action: Callable, focus: bool = false) -> void:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0,50)
	button.pressed.connect(action)
	box.add_child(button)
	if focus:
		button.grab_focus()

func _show_menu() -> void:
	playing = false
	paused = false
	get_tree().paused = false
	hud.hide()
	var box := _panel("Стрибай. Збирай. Перемагай.", "3 рівні • монети • контрольні точки\nДістанься зеленого прапора на кожному рівні.")
	_button(box, "Почати гру", start_game, true)
	box.add_child(_label("A / D або ← / → — рух\nПробіл / W / ↑ — стрибок     •     Esc — пауза", 18, Color("aebdd8")))

func start_game() -> void:
	banked_coins = 0
	deaths = 0
	playing = true
	_load_level(0)

func _load_level(index: int) -> void:
	get_tree().paused = false
	paused = false
	level_index = index
	if is_instance_valid(level):
		remove_child(level)
		level.queue_free()
	level = LevelScript.new()
	# World pauses normally; the UI/main node remains active.
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(level)
	level.build(index)
	level.coin_collected.connect(func(_total: int): _refresh_hud())
	level.completed.connect(_on_completed)
	level.player_died.connect(_on_death)
	level.checkpoint_reached.connect(func(): message_label.text = "Контрольну точку збережено!")
	backdrop.accent = Color(LevelScript.LEVELS[index]["accent"])
	backdrop.queue_redraw()
	message_label.text = ""
	overlay.hide()
	hud.show()
	_refresh_hud()

func _refresh_hud() -> void:
	level_label.text = "%d / 3   %s" % [level_index + 1, LevelScript.LEVELS[level_index]["name"]]
	coin_label.text = "Монети: %d / %d" % [level.coins, level.get_coin_count()]
	death_label.text = "Загибелі: %d" % deaths

func _on_death() -> void:
	deaths += 1
	message_label.text = "Ще одна спроба!"
	_refresh_hud()

func _on_completed() -> void:
	banked_coins += level.coins
	get_tree().paused = true
	if level_index < 2:
		overlay_kind = "next"
		var box := _panel("Рівень пройдено!", "Зібрано монет: %d / %d\nЗагибелі за гру: %d" % [level.coins,level.get_coin_count(),deaths])
		_button(box, "Наступний рівень", func(): _load_level(level_index + 1), true)
		_button(box, "До головного меню", _return_menu)
	else:
		overlay_kind = "win"
		var box := _panel("Ти переміг!", "Усі 3 рівні пройдено.\nМонети: %d / 37     •     Загибелі: %d" % [banked_coins,deaths])
		_button(box, "Зіграти ще раз", start_game, true)
		_button(box, "До головного меню", _return_menu)

func _on_pause() -> void:
	paused = true
	overlay_kind = "pause"
	get_tree().paused = true
	var box := _panel("Пауза", "Перепочинь — твій прогрес на рівні збережено.")
	_button(box, "Продовжити", _resume, true)
	_button(box, "Почати рівень заново", func(): _load_level(level_index))
	_button(box, "До головного меню", _return_menu)

func _resume() -> void:
	paused = false
	get_tree().paused = false
	overlay.hide()

func _return_menu() -> void:
	if is_instance_valid(level):
		remove_child(level)
		level.queue_free()
	_show_menu()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if playing and event.keycode == KEY_ESCAPE:
		if paused:
			_resume()
		elif not get_tree().paused:
			_on_pause()
		get_viewport().set_input_as_handled()
	elif playing and event.keycode == KEY_R and (not get_tree().paused or paused):
		_load_level(level_index)
		get_viewport().set_input_as_handled()
